"""Local, read-only viewer for Seagrass Mapping Survey responses.

Reads participant_responses.sqlite (Streamlit app) and/or export files from the
offline web app in docs/ (the *_all.json file, or the .zip download).
Launch locally (not on a public server):
    python -m streamlit run seagrass_responses_viewer.py --server.address 127.0.0.1
"""

import io
import json
import sqlite3
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

DB_PATH = Path(__file__).resolve().parent / "participant_responses.sqlite"
TABLES = (
    "participant_surveys",
    "mapped_hexes",
    "hex_values",
    "participant_submissions",
)

st.set_page_config(page_title="Seagrass Survey Responses", layout="wide")
st.title("Seagrass Mapping Survey — Responses")
st.caption("Local research-team viewer. Do not deploy this page publicly or publish the database.")


def read_data():
    connection = sqlite3.connect(DB_PATH)
    try:
        connection.execute("PRAGMA query_only = ON")
        existing = {
            row[0]
            for row in connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        }
        return {
            table: (
                pd.read_sql_query(f'SELECT * FROM "{table}"', connection)
                if table in existing else pd.DataFrame()
            )
            for table in TABLES
        }
    finally:
        connection.close()


@st.cache_data(show_spinner=False)
def load_data(last_modified):
    return read_data()


def read_export(name, raw):
    """Tables from one offline web-app export (.json bundle, or .zip containing it)."""
    if name.lower().endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            bundles = [n for n in archive.namelist() if n.endswith("_all.json")]
            if not bundles:
                raise ValueError("no *_all.json file inside the .zip")
            raw = archive.read(bundles[0])
    bundle = json.loads(raw.decode("utf-8"))
    if bundle.get("format") != "seagrass-survey-export":
        raise ValueError("not a Seagrass survey export")
    return {table: pd.DataFrame(bundle["tables"].get(table, [])) for table in TABLES}


def merge_sources(sources):
    """Combine SQLite and device exports, keeping each participant's newest copy.

    The same participant can appear in several exports (devices export
    everything each time), so take all of a participant's rows from the one
    source where their survey was most recently updated.
    """
    best = {}
    for index, tables in enumerate(sources):
        surveys = tables["participant_surveys"]
        latest = {}
        for table in TABLES:
            df = tables[table]
            if df.empty or "participant_id" not in df.columns:
                continue
            for pid in df["participant_id"].dropna().astype(str):
                latest.setdefault(pid, "")
        if not surveys.empty and "updated_at" in surveys.columns:
            for row in surveys.itertuples(index=False):
                latest[str(row.participant_id)] = str(row.updated_at or "")
        for pid, updated in latest.items():
            if pid not in best or updated >= best[pid][0]:
                best[pid] = (updated, index)
    merged = {}
    for table in TABLES:
        parts = []
        for index, tables in enumerate(sources):
            df = tables[table]
            if df.empty or "participant_id" not in df.columns:
                continue
            keep = df["participant_id"].astype(str).map(lambda pid: best.get(pid, (None, None))[1] == index)
            parts.append(df[keep])
        merged[table] = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
    return merged


def rank_values(raw):
    if not isinstance(raw, str) or not raw:
        return []
    try:
        values = json.loads(raw)
        return values if isinstance(values, list) else []
    except (ValueError, TypeError):
        return []


def export_geojson(hexes, values):
    benefits = {}
    for row in values.itertuples(index=False):
        benefits.setdefault((row.participant_id, row.hex_id), []).append(row.value_category)
    features = []
    for row in hexes.itertuples(index=False):
        try:
            geom = json.loads(row.geometry_geojson)
        except (ValueError, TypeError):
            continue
        features.append({
            "type": "Feature",
            "geometry": geom,
            "properties": {
                "participant_id": row.participant_id,
                "hex_id": row.hex_id,
                "focus_area": row.focus_area,
                "benefits": benefits.get((row.participant_id, row.hex_id), []),
            },
        })
    return json.dumps({"type": "FeatureCollection", "features": features}, ensure_ascii=False, indent=2)


with st.sidebar:
    st.header("Data sources")
    if st.button("Refresh responses"):
        st.cache_data.clear()
        st.rerun()
    uploads = st.file_uploader(
        "Offline app exports (*_all.json or .zip)", type=["json", "zip"],
        accept_multiple_files=True,
        help="Load the export from every device. Duplicates are merged automatically.",
    )

sources = []
if DB_PATH.is_file():
    sources.append(load_data(DB_PATH.stat().st_mtime_ns))
    st.caption(f"Includes local database: {DB_PATH.name}")
for upload in uploads or []:
    try:
        sources.append(read_export(upload.name, upload.getvalue()))
    except (ValueError, KeyError, zipfile.BadZipFile, UnicodeDecodeError) as exc:
        st.warning(f"Skipped {upload.name}: {exc}")
if not sources:
    st.info(
        "No responses loaded. Upload exports from the offline app in the sidebar, "
        "or place this viewer next to participant_responses.sqlite."
    )
    st.stop()

all_data = merge_sources(sources)
surveys = all_data["participant_surveys"]
hexes = all_data["mapped_hexes"]
values = all_data["hex_values"]
submissions = all_data["participant_submissions"]

ids = sorted({
    str(pid)
    for df in all_data.values()
    if not df.empty and "participant_id" in df.columns
    for pid in df["participant_id"].dropna()
})

with st.sidebar:
    chosen_id = st.selectbox("Participant", ["All participants", *ids])

if chosen_id != "All participants":
    filtered = {
        name: df.loc[df["participant_id"].astype(str) == chosen_id].copy()
        if "participant_id" in df.columns else df
        for name, df in all_data.items()
    }
else:
    filtered = {name: df.copy() for name, df in all_data.items()}

fsurveys = filtered["participant_surveys"]
fhexes = filtered["mapped_hexes"]
fvalues = filtered["hex_values"]

m1, m2, m3, m4 = st.columns(4)
m1.metric("Participant records", len(fsurveys))
m2.metric("Completed surveys", int(fsurveys["completed_at"].notna().sum()) if "completed_at" in fsurveys else 0)
m3.metric("Selected hexagons", len(fhexes))
m4.metric("Benefit assignments", len(fvalues))

survey_tab, map_tab, export_tab = st.tabs(["Survey answers", "Mapped benefits", "Export data"])

with survey_tab:
    if fsurveys.empty:
        st.info("No saved survey answers found.")
    else:
        display = fsurveys.copy()
        if "top_benefits_json" in display.columns:
            ranks = display["top_benefits_json"].apply(rank_values)
            for i in range(3):
                display[f"Q7_rank_{i + 1}"] = ranks.apply(lambda arr, i=i: arr[i] if len(arr) > i else "")
        st.dataframe(display, use_container_width=True, hide_index=True)
        st.caption("Some multiple-choice answers (e.g. goods uses and concerns) remain in JSON columns.")

with map_tab:
    if fvalues.empty:
        st.info("No mapped benefit assignments found. Participants must press 'Save mapped benefits'.")
    else:
        st.subheader("Hexagon × benefit records")
        st.dataframe(fvalues, use_container_width=True, hide_index=True)
        st.subheader("Most selected benefits")
        counts = fvalues["value_category"].value_counts().rename_axis("Benefit").reset_index(name="Hexagon selections")
        st.dataframe(counts, use_container_width=True, hide_index=True)
    if not fhexes.empty:
        st.caption("A hexagon may appear more than once in the benefit table because it can represent multiple benefits.")

with export_tab:
    st.write("Download records for analysis in Excel, R, Python, QGIS or ArcGIS Pro.")
    for table in TABLES:
        df = filtered[table]
        st.download_button(
            label=f"Download {table}.csv",
            data=df.to_csv(index=False).encode("utf-8-sig"),
            file_name=f"{table}.csv",
            mime="text/csv",
            key=f"export_{table}",
        )
    if not fhexes.empty:
        st.download_button(
            "Download mapped benefits as GeoJSON",
            data=export_geojson(fhexes, fvalues).encode("utf-8"),
            file_name="mapped_benefits.geojson",
            mime="application/geo+json",
        )
    st.caption("Keep raw responses access-controlled. Do not publish individual mapped locations without consent.")
